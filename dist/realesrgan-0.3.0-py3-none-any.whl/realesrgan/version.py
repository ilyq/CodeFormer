# GENERATED VERSION FILE
# TIME: Fri Jun 14 13:20:41 2024
__version__ = '0.3.0'
__gitsha__ = 'a4abfb2'
version_info = (0, 3, 0)
