# GENERATED VERSION FILE
# TIME: Fri Jun 14 15:14:49 2024
__version__ = '1.4.2'
__gitsha__ = '0103bdb'
version_info = (1, 4, 2)
