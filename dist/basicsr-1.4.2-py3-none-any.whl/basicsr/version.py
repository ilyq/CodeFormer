# GENERATED VERSION FILE
# TIME: Fri Jun 14 16:24:54 2024
__version__ = '1.4.2'
__gitsha__ = '209f88d'
version_info = (1, 4, 2)
